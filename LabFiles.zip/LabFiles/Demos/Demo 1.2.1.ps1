﻿Set-ExecutionPolicy -ExecutionPolicy Unrestricted
Get-ExecutionPolicy