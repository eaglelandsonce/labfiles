﻿5 -eq 5
100 -gt 10
10 -lt 100

"hello" -eq "HELLO"
"hello" -ceq "HELLO"

"hello" -like "*ll*"
"hello" -notlike "*o"

