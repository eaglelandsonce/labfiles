﻿<#

The intent with the demonstrations is to run them in the ISE.
Most demos are broken into sections; highlight the commands
in each section and press F8 to run just the highlighted commands.

Note that students should have a LabFiles folder on their
C:\ drive.
Students will find the demo scripts, lab answers, and lab starting
points in that location. They will also find the various tools
described in the student manual.

In some cases, students will need to copy PowerShell modules from
ClassPack to their Modules folder. This starts happening in Module 11.

#>