﻿<#

Point out:

1. How to use the Layout buttons in the toolbar

2. How to show/hide the Command Pane

3. How to switch from full-screen editor to full-screen console
 
4. How to run a script file

5. How to adjust the font size


#>