﻿Get-InfoNIC -ComputerName Alpha
Get-InfoOS -ComputerName Alpha